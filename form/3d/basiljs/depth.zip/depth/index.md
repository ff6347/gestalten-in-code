---  
layout: default
title: Depth - Simple 3D Cube 
tags: [basil.js,3D, form, basic]
permalink: /form/depth-3d/
summary: A simple 3D form in InDesign
---  

Just a simple cube created with Basil.js and InDesign

<!-- more -->

{% include out.html %}

```js
{% include_relative depth.jsx %}
```



