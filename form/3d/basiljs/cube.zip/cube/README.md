![](out.png)  
![](cube-01.png)  
![](cube-02.png)  
![](cube-03.png)  