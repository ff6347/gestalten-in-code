---  
layout: default
title: 3D Cubes
tags: [basil.js,3D, form, advanced]
permalink: /form/cube-3d/
summary: Creating 3D forms in InDesign
---  

A basic 3D scene mapped from 2D

<!-- more -->

{% include out.html %}

```js 
{% include_relative cube.jsx %}
```

