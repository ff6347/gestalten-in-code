---
layout: default
author: Fabian Morón Zirfas
title: Space Through Foreshortening
tags: [processing, form, Law of Space ]
permalink: /form/space-through-foreshortening/
summary: If a elements get foreshortend the feeling of depth is created   
archive: space_through_foreshortening.zip
---

{{page.summary}}


<!-- more -->

{% include out.html %}

```js
{% include_relative space_through_foreshortening.pde %}
```



