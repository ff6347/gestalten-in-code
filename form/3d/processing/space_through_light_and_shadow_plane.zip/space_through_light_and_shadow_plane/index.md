---
layout: default
author: Fabian Morón Zirfas
title: Space Through Light and Shadow Plane
tags: [processing, form, Law of Space ]
permalink: /form/space-through-light-and-shadow-plane/
summary: A spacial object gets spacial by its shadows.     
archive: space_through_light_and_shadow_plane.zip
---

{{page.summary}}


<!-- more -->

{% include out.html %}

```js
{% include_relative space_through_light_and_shadow_plane.pde %}
```



