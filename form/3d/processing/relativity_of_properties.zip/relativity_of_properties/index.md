---
layout: default
author: Fabian Morón Zirfas
title: Relativity of Properties
tags: [processing, form, Law of Relativity of Properties ]
permalink: /form/relativity-of-properties/
summary: Differences between elements are percept as bigger as they are. Both of these rectangles have the same size. The white one has the same size as the black one. Just by standing on a different ground it "blows up".  
archive: relativity_of_properties.zip
---

{{page.summary}}


<!-- more -->

{% include out.html %}

```js
{% include_relative relativity_of_properties.pde %}
```



