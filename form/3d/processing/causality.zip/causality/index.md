---
layout: default
author: morphogen
author-url: http://www.openprocessing.org/user/11641
title: Causality
tags: [processing, form, Law of Causality ]
permalink: /form/causality/
summary: The perception wants to give forms that stand together a meaning. It tries to bring them into contenxt.  
archive: causality.zip
---

{{page.summary}}


<!-- more -->

{% include out.html %}

```js
{% include_relative causality.pde %}
```



