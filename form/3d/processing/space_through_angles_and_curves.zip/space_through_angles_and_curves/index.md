---
layout: default
author: Fabian Morón Zirfas
title: Space Through Angles And Curves
tags: [processing, 3d,form, Law of Space ]
permalink: /form/space-through-angles-and-curves/
summary: Angles and curves create the perception of space.
archive: space_through_angles_and_curves.zip
---

{{page.summary}}

<!-- more -->

{% include out.html %}

```js
{% include_relative space_through_angles_and_curves.pde %}
```



