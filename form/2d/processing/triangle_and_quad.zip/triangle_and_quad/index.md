---
layout: default
author: Fabian Morón Zirfas
title: Triangle and Quad
tags: [processing, form, Law of Closure,Law of Prägnanz,todo ]
permalink: /form/triangle-and-quad/
summary: Even though there is a skewed rectangle in the we see the triangles. They are more prägnant.  
archive: triangle_and_quad.zip
---

<div class="hero">{{page.summary}}</div>

<!-- more -->

{% include out.html %}

```java
{% include_relative triangle_and_quad.pde %}
```



