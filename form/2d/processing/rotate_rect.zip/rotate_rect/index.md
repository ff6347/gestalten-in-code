---
layout: default
author: Fabian Morón Zirfas
title: Proximity
tags: [processing, 2D, form, Law of Proximity, repeat, ]
permalink: /form/rotate-rectangle/
summary: A figure always stands on a ground.
archive: proximity.zip
---

<div class="hero">{{ page.summary }}</div>

<!-- more -->

{% include out.html %}

```java
{% include_relative rotate_rect.pde %}
```


