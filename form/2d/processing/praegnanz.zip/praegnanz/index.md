---   
layout: default
author: Fabian Morón Zirfas
title: Prägnanz
tags: [processing,2D, form,"Law of Prägnanz", ]
permalink: /form/praegnanz/
summary: The "Law of Prägnanz". Even though this is only some lines on a 2D plane we see the cube.  
archive: praegnanz.zip

---  

<div class="hero">{{ page.summary }}</div>

<!-- more -->

{% include out.html %}

```java
{% include_relative praegnanz.pde %}
```


