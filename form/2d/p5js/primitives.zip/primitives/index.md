---
layout: default
title: Primitives
tags: [P5.js, form]
permalink: /form/primitives
summary: just primitive shapes
---

This sketch shows how to draw with basic shapes.

<!-- more -->

<div id="sketch"></div>

```js
{% include_relative index.js %}
```

<script type="text/javascript" src="{{site.baseurl}}/assets/js/p5.min.js"></script>
<script type="text/javascript" src="{{site.baseurl}}/{{ page.path | replace:'.md','.js' }}"></script>