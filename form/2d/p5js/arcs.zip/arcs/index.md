---  
layout: default
title: Arcs
tags: [P5.js, form]
permalink: /form/primitives
summary: Just some arcs
---  

Just an arc

<!-- more -->


<div id="sketch"></div>

```js
{% include_relative index.js %}
```

<script type="text/javascript" src="{{site.baseurl}}/assets/js/p5.min.js"></script>
<script type="text/javascript" src="{{site.baseurl}}/{{ page.path | replace:'.md','.js' }}"></script>