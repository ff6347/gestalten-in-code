---
layout: default
title: Primitives in InDesign
tags: [Basil.js, form]
permalink: /form/primitives-id/
summary: Primitives created in InDesign
---


<!-- more -->

{% include out.html %}

```js
{% include_relative primitives.jsx %}
```


