---
layout: default
title: Displacement Map
tags: [todo]
permalink: /form/ribbon/
summary: A sketch using a grayscale image as displacement map
---

Some displacexment_map.

<!-- more -->

{% comment %}
{% include out.html %}
{% highlight java %}
{% include_relative displacement_map.pde %}
{% endhighlight %}
{% endcomment %}


