---
layout: default
title: Just a path
tags: [Basil.js, form]
permalink: /form/path/
summary: Drawing paths is easy
---

Some path.  
<!-- more -->

{% include out.html %}

```js
{% include_relative path.jsx %}
```


