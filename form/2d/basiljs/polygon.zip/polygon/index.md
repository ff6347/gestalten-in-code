---
layout: default
title: Polygons
tags: [Basil.js, form]
permalink: /form/polygon-id/
summary: Polygons in a circle
---


<!-- more -->

{% include out.html %}

```js
{% include_relative polygon.jsx %}
```


