---
layout: default
title: Triangle with Shadow
tags: [Basil.js,distored,duplicate,form]
permalink: /form/triangle-shadowed/
summary: Shows how to create a fake shadow.
---

Some triangles with shadows

<!-- more -->

{% include out.html %}

```js
{% include_relative triangle.jsx %}
```


