---
layout: default
author: Fabian Morón Zirfas
title: Space Through Color
tags: [processing, color, library, HSB, color-model, ]
permalink: /color/space-through-color/
summary: Different colors create different perceptions of depth. Warm colors are near cold colors are far.  
---

<div class="hero">{{page.summary}}</div>

<!-- more -->

{% include out.html %}

```java
{% space_through_colour.pde %}
```



