---
layout: default
author: Fabian Morón Zirfas
title: Space Through Color In Gray
tags: [processing, color, library, color-model, ]
permalink: /color/space-through-color-gray/
summary: Different colors create different perceptions of depth. Depending on the ground they stand on.  
---

<div class="hero">{{page.summary}}</div>

<!-- more -->

{% include out.html %}

```java
{% space_through_colour_grey.pde %}
```



