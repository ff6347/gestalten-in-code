layout: p5js
author: Edmundo Mejía Galindo
author-url: [https://github/edgalindo..........xxxxxxxx //ACHTUNG!!!: ÄNDERN!
title: Grid
tags: P5.js, "Law of Proximity", "Law of Connected-Elements", "Law of Proximity", "Multistable-perception" Chance, Grid
permalink: /grid/Grid/
summary: This sample shows a dynamic grid, that changes the width and height of itself.  
---

The grid changes the size of the rectangles that are built through the grid each time by clicking the updating button. It is a non symetric drawn horizontal and vertical line canvas, that makes it interesting for drawing sheet.  

![](path/to/another/image.png) //ACHTUNG!!!: ÄNDERN!
