

run 
    npm install  