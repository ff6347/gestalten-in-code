---
layout: default
author: Unknown
title: Paint
tags: [processing, interact, ]
permalink: /interact/paint/
summary: A dead simple paint program.
archive: paint.zip
---

{{page.summary}}

<!-- more -->

{% include out.html %}

```js
{% include_relative paint.pde %}
```



