layout: p5js
author: Edmundo Mejía Galindo
author-url: [https://github/edgalindo..........xxxxxxxx //ACHTUNG!!!: ÄNDERN!
title: Contrast
tags: P5.js, "Law of Closure", "Law of Connected-Elements", "Law of Contrast", "Law of Figure-Ground", "Law of Regularity", "Law of Similarity", "Law of Simplicity", "Law of Symmetry", Interaction, Contrast
permalink: /contrast/Contrast/
summary: This sample shows the contrast through the background color and the shape changing color.
---

The contrast of this image is strong, because the color combination between black and white is the biggest distance between both colors in the color theorie.

![](path/to/another/image.png) //ACHTUNG!!!: ÄNDERN!
