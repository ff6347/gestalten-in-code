---   
layout: default
author: Fabian Morón Zirfas
title: Boxen
tags: [processing, repeat, chance, Law of Similarity,]
permalink: /repeat/boxen/
summary: Generate a box with something on its corners.    
archive: boxen.zip

---  

<div class="hero">{{ page.summary }}</div>

<!-- more -->

{% include out.html %}

```java
{% include_relative boxen.pde %}
```


