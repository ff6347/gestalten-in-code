---   
layout: default
author: Fabian Morón Zirfas
title: Basil.js Logo
tags: [processing, repeat, chance,Law of Closure,]
permalink: /repeat/basiljs-logo/
summary: Okay. I know totaly wired to have the Basil.js logo made in Processing. The right tool for the right job. Processing handles the creation of animations way better then Basil.js does
archive: basil_logo.zip

---  

<div class="hero">{{ page.summary }}</div>

<!-- more -->

{% include out.html %}

```java
{% include_relative basiljs_logo.pde %}
```


