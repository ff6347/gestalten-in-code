---   
layout: default
author: Fabian Morón Zirfas
title: Small Multiples
tags: [processing, repeat, chance]
permalink: /repeat/small-multiples/
summary: Generate multiple elements based on the same rules.    
archive: small_multiples.zip

---  

<div class="hero">{{ page.summary }}</div>

<!-- more -->

{% include out.html %}

```java
{% include_relative small_multiples.pde %}
```


