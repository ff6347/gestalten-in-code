---
layout: default
author: Fabian Morón Zirfas
title: Spiro
tags: [extendscript, repeat, form, ]
permalink: /repeat/spiro/
summary: one single spiro.  
archive: spiro.zip
---

<div class="hero">{{page.summary}}</div>


<!-- more -->

{% include out.html %}

```js
{% include_relative spiro.jsx %}
```



