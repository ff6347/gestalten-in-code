---
layout: default
author: Fabian Morón Zirfas
title: Vision
tags: [processing, grid, repeat, ]
permalink: /grid/vision/
summary: A optical problem. Take some distance from the image and try to spot all the circles.
archive: vision.zip
---

{{page.summary}}


<!-- more -->

{% include out.html %}

```js
{% include_relative vision.pde %}
```



