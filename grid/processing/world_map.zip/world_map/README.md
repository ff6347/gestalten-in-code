world map
=========

simple equirectangular mapping in Processing

see also [https://github.com/FH-Potsdam/hello-processing-py-world/tree/master/world_map](https://github.com/FH-Potsdam/hello-processing-py-world/tree/master/world_map)
