---
layout: default
title: Margins
tags: [Basil.js, grid, repeat, chance]
permalink: /grid/margins/
summary: A simple sketch that shows how to set margins for an InDesign document and also for a text frame.
archive: margins.zip
---

{{page.summary}}


<!-- more -->

{% include out.html %}

```js
{% include_relative margins.jsx %}
```



